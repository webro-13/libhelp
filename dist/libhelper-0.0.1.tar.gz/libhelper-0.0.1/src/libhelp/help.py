def fr():
    open('log.txt', 'r')


def fw():
    open('log.txt', 'w')


def fa():
    open('log.txt', 'a')
